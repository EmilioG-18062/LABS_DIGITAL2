/*//////////////////////////////////////////////////////////////////////////////
 * File:   device_config.h
 * Author: Emilio Gordillo 18062
 *
 * Proyecto SPI - DIGITAL 2
 * PIC Esclavo 2
 */

#ifndef DEVICE_CONFIG_H
#define	DEVICE_CONFIG_H

#define _XTAL_FREQ 8000000 //8MHz

#endif	/* DEVICE_CONFIG_H */


/*//////////////////////////////////////////////////////////////////////////////
 * File:   interrup_manager.h
 * Author: Emilio Gordillo 18062
 *
 * Proyecto SPI - DIGITAL 2
 * PIC Maestro
 */

#ifndef INTERRUPT_MANAGER_H
#define	INTERRUPT_MANAGER_H

#include <xc.h>

void INTERRUPT_MANAGER_Initialize(void);

#endif	/* INTERRUPT_MANAGER_H */


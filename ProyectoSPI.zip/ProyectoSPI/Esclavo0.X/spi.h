/*//////////////////////////////////////////////////////////////////////////////
 * File:   spi.h
 * Author: Emilio Gordillo 18062
 *
 * Proyecto SPI - DIGITAL 2
 * PIC Maestro
 */


#ifndef SPI_H
#define	SPI_H

#include <xc.h>
void SPI_MANAGER_Initialize(void);

#endif	/* SPI_H */


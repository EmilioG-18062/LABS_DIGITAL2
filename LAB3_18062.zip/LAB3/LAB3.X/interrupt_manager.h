/*//////////////////////////////////////////////////////////////////////////////
 * File:   interrupt_manager.h
 * Author: Emilio Gordillo 18062
 *
 * LABORATORIO 3 - DIGITAL 2
 */

#ifndef INTERRUPT_MANAGER_H
#define	INTERRUPT_MANAGER_H

#include <xc.h>

void INTERRUPT_MANAGER_Initialize(void);

#endif	/* INTERRUPT_MANAGER_H */


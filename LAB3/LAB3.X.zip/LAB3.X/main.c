/*//////////////////////////////////////////////////////////////////////////////
 * File:   main.c
 * Author: Emilio Gordillo 18062
 *
 * LABORATORIO 3 - DIGITAL 2
 */

/*//////////////////////////////////////////////////////////////////////////////
 * LIBRERIAS
 */
#include "lcs.h"

/*//////////////////////////////////////////////////////////////////////////////
 * MACROS
 */

/*//////////////////////////////////////////////////////////////////////////////
 * VARIABLES
 */
uint8_t adc_value = 0;
uint8_t adc_channel_pointer = 0;
uint8_t i = 0;
int contador=0;
int LecturaUSART=0;

uint16_t voltage_int = 0;

float voltage = 0.00;

char Buffer[20];
char Buffer1[20];
char digits[3];

/*//////////////////////////////////////////////////////////////////////////////
 * INTERRUPCIONES
 */
void __interrupt () myISR(void){
    
    //ADC Interrups
    if (PIR1bits.ADIF == HIGH && ADCON0bits.GO_nDONE == LOW){
        adc_value = ADRESH;
        voltage = adc_value;
        adc_channel_pointer++;
        ADC_FLAG_SetLow();
        if (contador == 255){contador = 0;}
        else{contador++;}
    }
    
    if(RCIF==1){//Si se levanta la bandera del UART
        RCIF=0;//apaga la bandera del UART
        LecturaUSART=Read_USART();  //guardar el valor recibido
        //comparar el valor con + o -, si es + aumenta el contador, si es - decrementa el contador
        if(LecturaUSART=='+'){contador++;} 
        else if(LecturaUSART=='-'){contador--;}
    }
    
}

/*//////////////////////////////////////////////////////////////////////////////
 * PROTOTIPOS DE FUNCIONES
 */

/*//////////////////////////////////////////////////////////////////////////////
 * CICLO PRINCIPAL
 */
void main(void) {
    SYSTEM_Initialize();
    GOnDONE_SetHigh();
    
    LCDGoto(0,0);
    LCDPutStr(" S1    S2    S3 ");
    
    while(HIGH){
        
        voltage_int = (uint16_t)(((voltage*500)/255));
        
        for (i = 0; i < 3; i++)
        {
           digits[i] = (char)(voltage_int % 10);
           voltage_int /= 10;
        }  
        
        if (!adc_channel_pointer){
            
            sprintf(Buffer, "%i.%i%iV", digits[2],digits[1],digits[0]);
            LCDGoto(0,1);
            LCDPutStr(Buffer);
            
        }
        
        if (adc_channel_pointer){
                    
            sprintf(Buffer, "%i.%i%iV", digits[2],digits[1],digits[0]);
            LCDGoto(6,1);
            LCDPutStr(Buffer);
            
        }
        sprintf(Buffer1, "%i", contador);
        LCDGoto(12,1);
        LCDPutStr(Buffer1);

        if( !ADCON0bits.GO_nDONE ){
            ADCON0bits.CHS = adc_channel_pointer;
            if(adc_channel_pointer){
                adc_channel_pointer = 255;
            }
            __delay_us(25);
            GOnDONE_SetHigh();
        }
        
        Write_USART_String(Buffer);//enviar el string con los valores a la pc
        Write_USART(13);//13 y 10 la secuencia es para dar un salto de linea 
        Write_USART(10);;
    }
}
/*//////////////////////////////////////////////////////////////////////////////
 * END OF THE PROGRAM
 */
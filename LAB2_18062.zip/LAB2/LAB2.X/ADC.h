/* 
 * File:   ADC.h
 * Author: emili
 *
 * Created on 7 de febrero de 2021, 11:13 PM
 */

#ifndef ADC_H
#define	ADC_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* ADC_H */

